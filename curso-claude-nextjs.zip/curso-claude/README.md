# Domina Claude — Curso Pro Senior

Curso completo de Claude con diseño editorial, construido en Next.js 14.

## Despliegue en Vercel (paso a paso)

### Paso 1 — Crear cuenta en GitHub (gratis)
1. Ve a **github.com**
2. Haz clic en "Sign up"
3. Ingresa tu email, crea una contraseña, elige un nombre de usuario
4. Verifica tu email
5. Listo ✓

### Paso 2 — Subir este proyecto a GitHub
1. Inicia sesión en github.com
2. Haz clic en el botón verde **"New"** (esquina superior izquierda)
3. Nombre del repositorio: `curso-claude`
4. Marca como **Public** (necesario para Vercel gratuito)
5. Haz clic en **"Create repository"**
6. En la página siguiente, verás instrucciones. Elige **"upload an existing file"**
7. Arrastra todos los archivos de esta carpeta (descomprimida) al navegador
8. Haz clic en **"Commit changes"**
9. Listo ✓

### Paso 3 — Crear cuenta en Vercel (gratis)
1. Ve a **vercel.com**
2. Haz clic en "Sign Up"
3. Elige **"Continue with GitHub"** (más fácil — conecta ambas cuentas automáticamente)
4. Autoriza Vercel en GitHub
5. Listo ✓

### Paso 4 — Importar y desplegar
1. En el dashboard de Vercel, haz clic en **"Add New Project"**
2. Verás tu repositorio `curso-claude` — haz clic en **"Import"**
3. Vercel detecta automáticamente que es Next.js
4. No cambies nada — haz clic directo en **"Deploy"**
5. Espera ~2 minutos mientras construye el proyecto
6. ¡Listo! Vercel te da una URL del tipo `curso-claude-xxxx.vercel.app`

## Tu URL es pública, gratuita y con HTTPS activado automáticamente.

---

## Desarrollo local (opcional)

Si quieres editar el curso en tu computador:

```bash
# Necesitas Node.js instalado (nodejs.org)
npm install
npm run dev
# Abre http://localhost:3000
```

## Estructura del proyecto

```
curso-claude/
├── app/
│   ├── globals.css     # Todo el diseño editorial
│   ├── layout.js       # Layout raíz con fuentes
│   └── page.js         # Aplicación completa
├── lib/
│   └── data.js         # Módulos, lecciones, quiz, glosario
├── package.json
└── next.config.js
```

## Para expandir el contenido

Abre `lib/data.js` y agrega entradas al objeto `LESSON_CONTENT`:

```js
"2-0": {  // módulo 2, lección 0
  body: `<h2>Tu contenido aquí</h2><p>...</p>`,
  exercises: [{ num: "01", title: "Título", time: "15 min", desc: "Descripción", prompt: "Prompt de práctica" }]
}
```

Cada cambio que hagas en GitHub se despliega automáticamente en Vercel en ~1 minuto.
